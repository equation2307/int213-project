# BOLT

ELECTRICITY BILL MANAGEMENT SYSTEM
[SETUP](https://github.com/ameenkhan07/ebill/wiki/SETUP)

## TODO
* Redesign Landing page to include raw data about the potal and and signup in a modal popup <meh...>
* Change passowrd functionality for user
